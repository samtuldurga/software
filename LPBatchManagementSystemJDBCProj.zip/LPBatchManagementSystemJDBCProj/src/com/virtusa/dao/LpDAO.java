package com.virtusa.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.LP;

public interface LpDAO{
	
	

	
	LP lpProfileView(int userId) throws ClassNotFoundException, SQLException;

	boolean storeEmployeeDetails(LP lp) throws ClassNotFoundException, SQLException;

	
}
