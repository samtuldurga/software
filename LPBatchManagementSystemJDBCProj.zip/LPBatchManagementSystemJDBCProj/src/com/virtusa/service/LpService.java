package com.virtusa.service;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.model.LpModel;
import com.virtusa.model.UpdateLpDetailsView;


public interface LpService {
	
	


	LpModel retrieveLpDetails(int employeeId);

	boolean storeLpService(UpdateLpDetailsView updateLpDetailsView) throws ClassNotFoundException, SQLException;
	
	

}
