package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.virtusa.dao.LpDAO;
import com.virtusa.entities.LP;
import com.virtusa.helper.FactoryLpDAO;
import com.virtusa.model.LpModel;
import com.virtusa.model.UpdateLpDetailsView;

public class LpServiceImpl implements LpService {

	LpDAO lpDao;
	
    public LpServiceImpl(){
		
    this.lpDao=FactoryLpDAO.createLpDAO();
	}
	 
    
    @Override
	public LpModel retrieveLpDetails(int userId) {
		// TODO Auto-generated method stub
    	
		LP lp=null;
		LpModel lpModel=new LpModel();
		try {
			lp=lpDao.lpProfileView(userId);
			lpModel.setFullName(lp.getFirstName()+" "+lp.getLastName());
			lpModel.setContactDetails(lp.getEmail()+" "+lp.getPhoneNumber());
			lpModel.setRole(lp.getRole());
			
		
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println(lpModel);
		return lpModel;
	}


	@Override
	public boolean storeLpService(UpdateLpDetailsView updateModel) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		  System.out.println(updateModel);

		
		LP lp=new LP();
		lp.setFirstName(updateModel.getFirstName());
		lp.setLastName(updateModel.getLastName());
		lp.setEmail(updateModel.getEmail());
		lp.setPhoneNumber(updateModel.getPhoneNumber());
		lp.setRole(updateModel.getRole());
		lp.setCity(updateModel.getCity());
		lp.setState(updateModel.getState());
		//lp.setState(updateModel.getCountry());
		lp.setLpId(updateModel.getUserId());
		
		System.out.println(lp);
		boolean stored=lpDao.storeEmployeeDetails(lp);
		
		boolean result=false;
		if(stored)
			result=true;
		else
			result=false;
		
		return result;
	}

	 
}
