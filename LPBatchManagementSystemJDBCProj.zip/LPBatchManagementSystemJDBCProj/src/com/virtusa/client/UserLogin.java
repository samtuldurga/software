package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.controller.UserController;

public class UserLogin {
	
	
	public static void main(String[] args) {
		UserLogin.menu();
	}
	public static void menu() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter User Id:");
		int userId=sc.nextInt();
		System.out.println("Enter Password:");
		String password=sc.next();
		
		UserController userController=new UserController();
		userController.userAuthentication(userId, password);
		
		
	}

}
