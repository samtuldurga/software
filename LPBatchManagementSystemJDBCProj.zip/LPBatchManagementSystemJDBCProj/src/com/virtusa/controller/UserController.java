package com.virtusa.controller;

import com.virtusa.client.UserLogin;
import com.virtusa.entities.LP;
import com.virtusa.helper.FactoryUserService;
import com.virtusa.model.UserModel;
import com.virtusa.service.UserService;
import com.virtusa.view.LpView;

public class UserController {
	
	
	UserService userService;
	public UserController(){
		
		this.userService=FactoryUserService.createUserService();
	}
	
	

	public void userAuthentication(int userId,String password) {
		 
		UserModel userModel=new UserModel();
		userModel.setUserId(userId);
		userModel.setPassword(password);
		
		boolean userType=userService.userAuthenticationService(userModel);
		if(userType==true) {
		     
			LpView lpView=new LpView();
			//lpView.lpMenu();
			lpView.lpMenu(userModel.getUserId());
			
			
		}else {
			UserLogin ul = new UserLogin();
			System.out.println("Invalid user name or password");
			ul.menu();
		}
		
		
		
	
}}
