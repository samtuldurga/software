package com.virtusa.test;

import java.sql.SQLException;

import org.junit.Test;

import com.virtusa.dao.UserDAO;
import com.virtusa.dao.UserDaoImpl;
import com.virtusa.model.UserModel;

class TestUserDAOImpl {

	@Test
	public void test() {
		UserDAO userDAO=new UserDaoImpl();
		
			
	}

}
