package com.virtusa.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.virtusa.dao.UserDAO;
import com.virtusa.dao.UserDaoImpl;
import com.virtusa.model.UserModel;

class TestUserDAOImpl {

	@Test
	public void test() {
		UserDAO userDAO=new UserDaoImpl();
		
			
	}

}
