package com.virtusa.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.virtusa.dao.LpDAO;
import com.virtusa.dao.LpDAOImpl;
import com.virtusa.entities.LP;



class LpDAOImplTest {

	@Test
	public void getLppossitive_test(int userId) {
		
		LpDAO lpDAO=new LpDAOImpl();
		
		try {
			List<LP> lpLists=
					(List<LP>) lpDAO.lpProfileView(userId);
			assertEquals(true,lpLists.size()>0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}
		
		
	
	}

}
