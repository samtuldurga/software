package com.virtusa.helper;

import com.virtusa.dao.LpDAO;
import com.virtusa.dao.LpDAOImpl;
import com.virtusa.dao.UserDAO;

public class FactoryLpDAO {
	
	public static LpDAO createLpDAO(){
		LpDAO lpDAO=new LpDAOImpl();
		return lpDAO;

}
}