package com.virtusa.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import com.virtusa.dao.UserDAO;
import com.virtusa.dao.UserDaoImpl;
import com.virtusa.model.UserModel;

class TestUserDAOImpl {

	@Test
	public void test() {
		UserDAO userDAO=new UserDaoImpl();
		UserModel userModel=new UserModel();
		int userId=userModel.getUserId();
		String password=userModel.getPassword();
		
			
		
			
	}

}
