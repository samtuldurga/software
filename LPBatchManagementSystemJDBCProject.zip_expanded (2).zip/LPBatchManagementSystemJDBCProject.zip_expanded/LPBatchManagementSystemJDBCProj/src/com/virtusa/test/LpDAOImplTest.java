package com.virtusa.test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.SQLException;


import org.junit.Test;

import com.virtusa.dao.LpDAO;
import com.virtusa.dao.LpDAOImpl;
import com.virtusa.entities.LP;



public class LpDAOImplTest {

	@Test
	public void getLppossitive_test() {
		LP lp=new LP();
		LpDAO lpDAO=new LpDAOImpl();
		
		try {
			int userId=lp.getLpId();
			LP lps=lpDAO.lpProfileView(userId);
			assertEquals(true,lps!=null);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}
	
	
	}
	

}
