package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.entities.User;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.UserModel;
import com.virtusa.view.LpView;

public class UserDaoImpl implements UserDAO {

	@Override
	public boolean userAuth(int userId,String password) throws SQLException, ClassNotFoundException {
		
		
			Connection connection=ConnectionManager.openConnection();
			boolean result=false;
			PreparedStatement statement = connection.prepareStatement("select*from USERS_LOGIN_TABLE where( user_id=? and password=?)");
			statement.setInt(1, userId);
			statement.setString(2, password);
            

         
			
		    ResultSet results=statement.executeQuery();
		  // System.out.println("1");
		    // 	User user=new User();
             if(results.next()) {
            	 //System.out.println("2");
            	 System.out.println(results.getInt("user_id"));
     		    System.out.println(results.getString("password"));
     		    
            	    result=true;
            	 
             }else
		    
             ConnectionManager.closeConnection();
			return result;
			
			
				
			
			
			 
	

}		
}

