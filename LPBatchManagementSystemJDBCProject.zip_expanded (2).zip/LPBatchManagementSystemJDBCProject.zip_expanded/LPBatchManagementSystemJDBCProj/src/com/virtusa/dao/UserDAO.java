package com.virtusa.dao;

import java.sql.SQLException;

import com.virtusa.entities.User;
import com.virtusa.model.UserModel;
import com.virtusa.view.LpView;

public interface UserDAO {
	public boolean userAuth(int userId,String password) throws SQLException, ClassNotFoundException;

	
}
