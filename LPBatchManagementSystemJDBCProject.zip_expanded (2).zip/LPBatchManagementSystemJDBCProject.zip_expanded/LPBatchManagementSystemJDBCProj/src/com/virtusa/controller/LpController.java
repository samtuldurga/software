package com.virtusa.controller;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.helper.FactoryLpDAO;
import com.virtusa.helper.FactoryLpService;
import com.virtusa.model.LpModel;
import com.virtusa.model.UpdateLpDetailsView;
import com.virtusa.service.LpService;
import com.virtusa.view.LpView;

public class LpController {
	
	LpService lpService;
	
	public LpController() {
		
		this.lpService=FactoryLpService.createLpService();
	}

   public void retrieveLpDetails(int userId) {
	  
	
		LpModel lpModel=lpService.retrieveLpDetails(userId);
		LpView lpView=new LpView();
		lpView.displayDetails(lpModel);
		
	
}

public void storeLp(UpdateLpDetailsView updateLpDetailsView) throws ClassNotFoundException, SQLException {
	
	LpView lpView=new LpView();
	System.out.println(updateLpDetailsView);
	
	int uId=updateLpDetailsView.getUserId();

	boolean result=lpService.storeLpService(updateLpDetailsView);
	
	if(result) {
		lpView.storeSuccess(uId);
		
	}else {
		
		lpView.storeUnSuccess(uId);
	}

		
	
}
}
